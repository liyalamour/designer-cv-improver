# Designer CV Block Layouts

Use these schematic maps when making a visual CV. They describe information hierarchy, not exact pixel dimensions.

`1` = contact and identity; `2` = work experience; `3` = education; `4` = supporting information such as skills, awards, certificates, languages, methods, or selected projects.

## Swiss Utility — experience-first rail

```text
+-----------------------+
|           1           |
+---------------+-------+
|               |   3   |
|       2       +-------+
|               |   4   |
+---------------+-------+
```

Use when work history is the strongest proof and supporting information is compact.

## Quiet Editorial — statement then story

```text
+-----------------------+
|           1           |
+-----------------------+
|                       |
|           2           |
|                       |
+-----------+-----------+
|     3     |     4     |
+-----------+-----------+
```

Use when the candidate has a concise senior positioning statement and a cohesive career narrative.

## Structured Rows — evidence gallery

```text
+-------+---------------+
|   1   |               |
+-------+       2       |
|                       |
+-----------+-----------+
|     3     |     4     |
+-----------+-----------+
```

Use when roles are compact and outcome-rich, with education and supplementary proof of similar weight.

## Soft Studio — portfolio rail

```text
+-----------------------+
|           1           |
+-------+---------------+
|   3   |               |
+-------+       2       |
|   4   |               |
+-------+---------------+
```

Use when projects and visual craft are central, while qualifications live in a warm, quiet rail.

## Cobalt System — system dashboard

```text
+-----------+-----------+
|     1     |     4     |
+-----------------------+
|                       |
|           2           |
|                       |
+-----------------------+
|           3           |
+-----------------------+
```

Use when technical methods and systems depth deserve visibility before the career detail.

## ATS-Safe Linear — zero ambiguity

```text
+-----------------------+
|           1           |
+-----------------------+
|           2           |
+-----------------------+
|           3           |
+-----------------------+
|           4           |
+-----------------------+
```

Use for portals and parsing-sensitive submissions.

## Sizing Rules

- Let block 2 take the largest contiguous area unless the candidate is a student with materially stronger projects.
- Do not force equal-sized blocks. Give 1 the smallest workable footprint; expand 3 or 4 only when there is real content.
- Keep the order and grouping in the chosen map unless content quantity makes the arrangement unreadable.
- Do not create a fifth decorative block. Empty space is a deliberate part of the composition.
