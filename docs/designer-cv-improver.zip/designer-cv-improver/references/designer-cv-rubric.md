# Designer CV Rubric

Use this rubric to diagnose a design CV before rewriting. Prioritize issues that affect role fit, evidence, and recruiter scan speed.

For Product Design Manager, Senior Product Design Manager, Design Lead, Head of Design, or other leadership CVs, also read `product-design-manager-screening-standards.md` and use it as the stricter screening layer.

## Score Areas

1. Target positioning
   - The top third clearly says what kind of designer the person is and what roles they want.
   - The summary connects discipline, domain, seniority, and value. Avoid vague claims such as "creative problem solver" unless backed by evidence.
   - The CV aligns to the target: product design, UX/UI, UX research, service design, brand, visual design, motion, design systems, content design, design management, or design leadership.

2. Recruiter scan
   - Name, title, location or work authorization if relevant, email, portfolio, LinkedIn, and core role are easy to find.
   - The first screen or first page makes seniority and strongest evidence obvious.
   - Section order suits the candidate: experience first for working designers, selected projects first for juniors or career changers when experience is thin.

3. Design impact evidence
   - Bullets explain what was designed, for whom, why it mattered, and what changed.
   - Strong evidence can include launch outcomes, conversion, retention, activation, task success, accessibility, design-system adoption, support-ticket reduction, research confidence, delivery speed, stakeholder alignment, or portfolio-quality case studies.
   - Use exact metrics only when the user provided them. If metrics are absent, use concrete scope and observed outcomes instead of inventing numbers.

4. Craft and process signals
   - The CV shows how the designer thinks: research, synthesis, information architecture, interaction design, visual systems, prototyping, usability testing, workshop facilitation, experimentation, accessibility, handoff, and iteration.
   - Tools support the story but do not dominate it. "Figma, FigJam, Miro, Adobe CC" is weaker than evidence of judgment and outcomes.
   - Portfolio links and case studies are visible and aligned to the role.

5. Collaboration and operating model
   - Bullets name meaningful partners when relevant: PM, engineering, research, data, marketing, sales, customer support, executives, clients, agencies, or vendors.
   - Senior candidates should show influence beyond individual screens: strategy, roadmaps, systems, standards, hiring, mentoring, critique rituals, stakeholder management, or org-level design quality.

6. ATS and formatting
   - Prefer readable headings, single-column text flow, standard dates, text-based contact links, and common section labels.
   - Flag risks: tables, icons used as labels, heavy graphics, text boxes, low contrast, tiny type, multi-column layouts that scramble reading order, and portfolio links hidden in decorative elements.
   - For visually expressive CVs, suggest maintaining a parallel ATS-safe version.

## Seniority Signals

- Junior or early career: emphasize internships, coursework with real constraints, portfolio projects, craft range, collaboration, learning velocity, and shipped or testable work.
- Mid-level: emphasize end-to-end feature ownership, research-to-release execution, cross-functional delivery, measurable improvements, and business/product context.
- Senior: emphasize ambiguous problem framing, product strategy, systems thinking, influence across teams, measurable product outcomes, mentoring, and decision quality.
- Lead, principal, staff, or manager: emphasize org-level outcomes, design quality systems, roadmap influence, hiring, team rituals, coaching, executive communication, and durable standards.
- Product Design Manager or Design Lead: emphasize quantifiable product/design impact, title growth, team scope, leadership evidence, design-system or operating-model contributions, and the candidate's ability to attribute outcomes credibly to design work.

## Common Red Flags

- Summary could fit any designer or any profession.
- Bullets start with "responsible for" and stop at activities.
- Projects are described as screens, not decisions or outcomes.
- The CV lists every tool but omits portfolio, product context, users, constraints, and collaborators.
- Visual layout is beautiful but hard to scan, parse, print, or read on mobile.
- Metrics sound inflated or unsupported.
- The CV has no evidence for the target seniority.
- Case studies and CV tell different stories about the candidate's strengths.

## Prioritization

Use this severity scale when giving a critique:

- P1: Likely to block interviews or misrepresent level, role fit, evidence, contactability, or ATS parsing.
- P2: Meaningfully weakens competitiveness but is fixable with rewriting or reordering.
- P3: Polish issue that improves confidence, readability, or tone.

In recommendations, start with P1 and P2. Keep P3 short unless the user asks for detailed polish.
