# CV Version Comparison

For every uploaded CV that is being enhanced visually, prepare Version A and Version B before finalizing. Use identical factual content and improvements in both versions so the user compares design and information hierarchy—not different copy.

## Minimum Difference

Make the versions differ in both:

1. **Visual direction:** palette, typography, rules, and overall personality.
2. **Block composition:** different placement or proportional emphasis for blocks 1–4.

Do not offer a color swap, font swap, or minor spacing adjustment as a separate version.

## Suggested Pairings

| Candidate dynamic | Version A | Version B |
|---|---|---|
| Dense experience | Professional Experience | Senior Editorial |
| Senior leadership story | Senior Editorial | Product Systems |
| Early career or project-led | Portfolio Creative | Evidence-led |
| Visual or brand designer | Portfolio Creative | Senior Editorial |
| Technical UX/UI or systems | Product Systems | Professional Experience |
| ATS-first candidate | ATS-safe Linear | Professional Experience visual companion |

## Response Pattern

Show a preview or complete layout spec for each version, then write:

`I’ve prepared two directions using the same improved content. Which version should I refine for your final CV—Version A or Version B?`

If the user asks for another direction, prepare Version C only when it has a materially different visual voice and block map.
