# CV Version Comparison

For every uploaded CV that is being enhanced visually, prepare Version A and Version B before finalizing. Use identical factual content and improvements in both versions so the user compares design and information hierarchy—not different copy.

## Minimum Difference

Make the versions differ in both:

1. **Visual direction:** palette, typography, rules, and overall personality.
2. **Block composition:** different placement or proportional emphasis for blocks 1–4.

Do not offer a color swap, font swap, or minor spacing adjustment as a separate version.

## Suggested Pairings

| Candidate dynamic | Version A | Version B |
|---|---|---|
| Dense experience | Swiss Utility | Quiet Editorial |
| Senior leadership story | Quiet Editorial | Cobalt System |
| Early career or project-led | Soft Studio | Structured Rows |
| Visual or brand designer | Soft Studio | Quiet Editorial |
| Technical UX/UI or systems | Cobalt System | Swiss Utility |
| ATS-first candidate | ATS-Safe Linear | Swiss Utility visual companion |

## Response Pattern

Show a preview or complete layout spec for each version, then write:

`I’ve prepared two directions using the same improved content. Which version should I refine for your final CV—Version A or Version B?`

If the user asks for another direction, prepare Version C only when it has a materially different visual voice and block map.
