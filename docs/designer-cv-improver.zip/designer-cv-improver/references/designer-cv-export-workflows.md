# Designer CV Export Workflows

Use this reference when the user wants an enhanced CV delivered as a PDF, Figma file, or Figma-ready design spec.

For visual decisions, also read `designer-cv-visual-direction.md`. If the user has provided example CVs or visual references, derive the style direction from those examples before designing.

## Mode Decision

If the user has not chosen an output, ask them to pick one:

- Critique only: feedback against rubrics, no final file.
- Enhance + PDF: rewrite and lay out the CV, then export a final PDF.
- Enhance + Figma: rewrite and create a Figma design when connected Figma tools are available; otherwise deliver a Figma-ready spec.

If the user wants both ATS safety and visual polish, recommend two deliverables:

- ATS-safe PDF: text-first, simple structure, standard headings, minimal decoration.
- Designer visual PDF or Figma version: more crafted hierarchy while preserving readability.

## PDF Workflow

1. Confirm constraints:
   - Page size: US Letter or A4.
   - Length: one page, two pages, or no strict limit.
   - Style: ATS-safe, visual designer-friendly, or balanced.
   - Links: portfolio, LinkedIn, email, case studies.
   - Visual direction: default to white background, black/dark-gray text, one accent color maximum, and 2-column or 3-column layout for visual versions.
   - Text contrast: every text color must meet WCAG 2.1 AA against its actual background—4.5:1 for normal text and 3:1 for large text. Do not use low-contrast gray or accent text for metadata, links, or headings unless it passes.
   - Safe gutter: for A4, reserve at least 14 mm of uninterrupted white space on every edge. Apply the same principle proportionally to US Letter.

2. Create the content:
   - Rewrite the summary, selected experience bullets, projects, education, and skills.
   - Keep experience bullets concise, data-driven, and impact-first; avoid long paragraphs disguised as bullets.
   - Keep all facts sourced from the user. Mark missing metrics or details as placeholders if needed.
   - Preserve a visible portfolio link near the top.

3. Lay out the CV:
   - Use strong hierarchy, compact spacing, clear section labels, and readable typography.
   - Design around the strongest evidence, not decorative modules.
   - Prefer one column for ATS-safe versions.
   - Use 2-column or 3-column block layouts for visual versions to create breathing room and clearer grouping.
   - Use no more than two typefaces; rely on bold, italic, and size variation for hierarchy.
   - Use reasonable line height: readable but not overly loose.
   - Keep decoration restrained; small handwriting, a small personal logo, or a subtle gradient accent is allowed, but illustrations and icon-heavy systems are not.
   - Measure every text cell after wrapping. An experience row must grow to accommodate its employer, role, date, and description; do not independently position two text elements in the same horizontal space without verifying their bounding areas do not intersect.
   - When several employers or roles are compressed into one entry, split them into separate rows unless each label has a clearly allocated, non-overlapping text cell.

4. Calibrate page fill:
   - Render or preview the full page before final export.
   - Treat the safe gutter as unavailable space. For A4, no text, rules, icons, panels, or other visual elements may enter the outer 14 mm at the top, bottom, left, or right.
   - For one-page A4 or Letter visual CVs, aim for content to occupy roughly 90-96% of the usable page height, measured inside the safe gutter. Treat a contiguous blank lower area larger than roughly 10% of usable height as a layout defect unless the user explicitly requests a sparse concept.
   - If there is a large empty bottom band, first distribute existing sourced content through the page: strengthen the name/role hierarchy, use proportionate section spacing, separate experience entries cleanly, and anchor education/supporting proof in the lower third. Do not leave all light sections compressed at the top.
   - If a lower-band or side-column section approaches the bottom or side safe gutter, reflow it, shorten sourced copy, rebalance columns, or move low-priority content to a second page. Do not reduce body text below readable size and do not allow content to bleed into the margin.
   - Prefer controlled changes: modestly increase role/title scale, use proportionate section spacing, rebalance columns, enlarge only the strongest truthful positioning statement, or add a relevant sourced section. Keep adjacent blocks visually connected; do not make a single gap substantially larger than the gaps around it.
   - Do not pad with fake achievements, random decoration, giant marks, oversized icons, or line height so loose that related content disconnects. If the truthful content cannot create a balanced one-page composition, recommend a deliberately compact format rather than fake density.

5. Export and verify:
   - Use available document and PDF tools to create/render the final file.
   - Check page count, text clipping, link visibility, margins, WCAG 2.1 AA text contrast, page fill, and whether the strongest evidence appears in the top third.
   - Verify a visible white gutter on all four sides at normal viewing and print scale. Inspect the bottom edge and the last line of every column in particular.
   - Inspect the rendered page at normal viewing scale for collisions: employer vs. title, title vs. date, wrapped description vs. rule, and footer/rail content vs. neighboring blocks. Any overlap is a release blocker; reflow and render again before delivery.
   - If rendering is unavailable, provide polished CV copy plus layout instructions instead of claiming a finished PDF.

## Figma Workflow

1. Confirm whether Figma tooling is available:
   - If connected Figma tools are available, create or update a Figma file.
   - If no connected Figma session exists, deliver a Figma-ready spec with exact sections, copy, layout, typography, spacing, colors, and component notes.

2. Choose a Figma frame:
   - A4 portrait: 595 x 842 pt equivalent.
   - US Letter portrait: 612 x 792 pt equivalent.
   - Digital portfolio snapshot: 1440 px wide, only if the user wants a web-style version rather than a conventional CV.

3. Design principles:
   - Make the candidate name, role, portfolio link, and strongest positioning visible immediately.
   - Use restrained visual craft: careful typography, alignment, spacing, and hierarchy.
   - Use a white background with black/dark-gray text and at most one accent color.
   - Verify every text color passes WCAG 2.1 AA contrast on its actual background: 4.5:1 for normal text and 3:1 for large text.
   - Use 2-column or 3-column layout patterns to create breathing room.
   - Use no more than two typefaces and vary size, bold, and italic for reading hierarchy.
   - Reserve a consistent white safe gutter before placing content. For A4, keep at least 14 mm clear on the top, bottom, left, and right; no text or visual element may bleed into it.
   - Calibrate the frame so a one-page A4 or Letter design fills roughly 90-96% of usable height. For light content, distribute blocks through the lower third using measured spacing and anchored supporting content; do not leave the lower quarter blank unless the user requested a sparse concept.
   - Avoid decorative elements that make the CV hard to read, export, or adapt.
   - Build reusable text styles for name, role, section headings, company/title lines, body bullets, metadata, and links.
   - Use components only when they reduce repeated manual edits, such as section headers or experience blocks.

4. Handoff:
   - Name the file or page clearly, such as `Designer CV - Enhanced`.
   - Include an export-ready frame and, when useful, a separate notes frame explaining ATS tradeoffs.
   - Tell the user whether an actual Figma file was created or whether the deliverable is a Figma-ready spec.

## Verification Checklist

- The content is factually grounded in the user's source material.
- The target role and seniority are obvious in the top third.
- The portfolio link is visible and easy to copy.
- The strongest achievements are specific and credible.
- The layout does not clip text or bury critical information.
- No text, rules, icons, or blocks overlap. Wrapped experience rows have enough measured height, and every column cell has its own non-intersecting area.
- For A4, a clean white gutter of at least 14 mm is visible at the top, bottom, left, and right; lower-band blocks do not touch or exceed the bottom gutter.
- A one-page visual layout uses roughly 90-96% of usable page height intentionally; it does not leave a contiguous empty lower band larger than roughly 10% of usable height unless the user requested a sparse concept.
- The visual design follows Liya's aesthetic standards: white background, black text, one accent color maximum, max two typefaces, enough breathing room, and restrained personality.
- All text colors meet WCAG 2.1 AA contrast against their actual background: at least 4.5:1 for normal text and 3:1 for large text.
- The final output matches the user's chosen mode: critique, PDF, Figma file, or Figma-ready spec.
