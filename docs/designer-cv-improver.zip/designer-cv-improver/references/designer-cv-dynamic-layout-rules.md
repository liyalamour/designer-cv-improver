# Dynamic CV Layout Rules

Choose the layout from the candidate's content, not from aesthetics alone. Work with four blocks: `1` contact/identity, `2` work experience, `3` education, and `4` supporting information.

## Assess Each Block

Classify each block before designing:

- **1 — compact:** name, target role, and 2–4 contact links. Make it larger only when a senior positioning statement, portfolio tagline, or career identity earns it.
- **2 — light / standard / dense:** light = one role or mostly internships; standard = two or three evidence-rich roles; dense = four or more roles, management scope, or long outcome bullets.
- **3 — light / strong:** light = one degree; strong = relevant advanced study, thesis, honors, research, or several qualifications.
- **4 — light / proof-rich:** light = a generic skills list; proof-rich = meaningful awards, certifications, speaking, teaching, languages, design-system expertise, selected projects, or community leadership.

## Position and Size Rules

- **Dense 2:** Give experience the largest uninterrupted area. Select Professional Experience, Senior Editorial, Product Systems, or ATS-safe Linear. Do not split it into decorative cards.
- **Light 2 + strong 3/4:** Give education or supporting proof a visible rail or lower band. Prefer Portfolio Creative or Evidence-led. It is acceptable for 3 + 4 to collectively occupy more area than 2.
- **Proof-rich 4:** Put it near the top only when it establishes target-role credibility (for example, design-system certification, relevant award, or deep technical method). Otherwise keep it secondary.
- **Strong 3:** Place education before 4 in the rail or footer. Do not bury graduate study, research, or honors under a generic skill list.
- **Long 1:** Use Senior Editorial's full-width header; reduce its statement before shrinking work evidence.
- **All blocks light:** Use Evidence-led with a lower-third supporting band or ATS-safe Linear with deliberate vertical distribution. Preserve the outer gutter, but use the usable height: give the identity block a stronger scale, set measured spacing between sections, and anchor education/supporting proof near the lower third. Do not enlarge blocks indiscriminately or leave a large unused lower area.

## Content-to-Template Matching

| Candidate dynamic | Preferred template(s) | Why |
|---|---|---|
| Dense career history; compact education and skills | Professional Experience, Senior Editorial | Keeps 2 dominant and lets 3/4 support it. |
| Senior narrative; clear leadership point of view | Senior Editorial, Professional Experience | Gives 1 room for positioning and 2 a continuous story. |
| Internships, projects, awards, and active community work | Evidence-led, Portfolio Creative | Lets 3/4 contribute credible proof instead of becoming an afterthought. |
| Portfolio-led visual or brand work | Portfolio Creative, Evidence-led | Makes projects and craft part of the page's visual center. |
| Technical UX/UI or design-system depth | Product Systems, Professional Experience | Surfaces proof-rich 4 early without reducing 2. |
| Application portal or unknown parser | ATS-safe Linear | Retains a predictable reading sequence. |

## Adaptation Constraints

- Keep the selected map recognizable, but resize and reposition blocks when the evidence demands it.
- Reserve the page gutter before sizing any block. On A4, keep at least 14 mm of blank space on every edge; calculate all block sizes inside that safe area.
- When a footer, lower band, or right rail becomes too tall, reflow it above the gutter, reduce nonessential copy, or continue it on a second page. Never let the final line or decoration touch the page edge.
- Treat each employer, role, date, and description as a measured text cell. Do not combine multiple employers or multiple roles in a single row unless the cells can wrap without intersecting; otherwise split the row and recalculate its height.
- For a one-page A4 or Letter visual CV, target 90-96% usable-height occupancy. If the source content is light, distribute factual blocks across the page with proportionate spacing and a lower-third anchor; do not create a contiguous blank lower band larger than roughly 10% of usable height unless the user explicitly requests a sparse concept.
- Use at most one visually elevated supporting block; never make education, skills, awards, and certificates all compete with experience.
- Do not create empty outlined regions. Merge a sparse block with a related block or retain whitespace.
- Make the first third of the page communicate target role and strongest proof.
- Explain the selected composition in one sentence when presenting template options.
