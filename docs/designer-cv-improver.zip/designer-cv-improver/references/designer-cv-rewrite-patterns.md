# Designer CV Rewrite Patterns

Use these patterns to rewrite designer CV content into specific, credible application material.

## Experience Bullet Discipline

Experience bullets should be concise, data-driven, and impact-first.

Default rules:

- Keep most bullets to one line where layout allows, or roughly 14-24 words.
- Use 2-4 bullets per recent major role; use 1-2 bullets for older or less relevant roles.
- Start with the outcome or leadership action, then include scope and evidence.
- Prefer numbers: team size, product area scale, adoption, coverage, conversion, retention, revenue, cost, cycle time, user volume, experiment count, research sample, design-system usage, or launch scope.
- If a metric is missing, ask for it or use a visible placeholder. Do not soften the bullet into vague language.
- Remove filler such as "responsible for", "worked on", "helped with", "various", "multiple", "successfully", and long process narration.
- Do not repeat the same context across several bullets. Consolidate repeated context into the role header or one high-value bullet.

For Product Design Manager or Design Lead roles, every recent role should try to show at least one of:

- People leadership: team size, hiring, coaching, critique rituals, performance, or org scope.
- Product impact: metric movement, launch outcome, strategic decision, or business area.
- Operating leverage: design system, process, quality bar, research practice, or cross-functional alignment.

## Bullet Formulas

Prefer one of these structures:

- Led `[team/scope]` to improve `[metric/result]` by `[design/product action]`.
- Increased `[metric]` from `[baseline]` to `[result]` by redesigning `[flow/product/system]`.
- Reduced `[cost/friction/time]` by `[result]` through `[design decision/system/process]`.
- Established `[system/process/ritual]` adopted by `[teams/products]`, improving `[quality/speed/coverage]`.
- Managed `[number]` designers across `[product areas/platforms]`, delivering `[launch/outcome]`.

If the user lacks metrics, write scope-based bullets:

- Led onboarding redesign for a B2B analytics product, simplifying setup, permissions, and first-dashboard creation.
- Prioritized three checkout fixes with PM and engineering after synthesizing research on purchase-flow friction.

Do not imply numeric impact, launch status, or adoption unless the user supplied that evidence.

## Bullet Compression Examples

Weak:

`Responsible for managing a team of designers and improving the booking experience across multiple platforms.`

Stronger:

`Managed 8 designers across core booking funnels, shipping cross-platform improvements for web, iOS, and Android.`

Metric-ready:

`Managed 8 designers across booking funnels, improving [conversion/retention/task success] by [result] across web, iOS, and Android.`

Weak:

`Worked on the design system and helped the engineering team use components more consistently.`

Stronger:

`Expanded design-system coverage from [baseline] to [result], improving component reuse across [number] product teams.`

## Strong Verb Bank

Use precise verbs suited to design work:

- Research and discovery: interviewed, observed, synthesized, mapped, audited, tested, validated, triangulated.
- Product design: redesigned, prototyped, simplified, structured, modeled, iterated, shipped, optimized.
- Systems: standardized, tokenized, documented, governed, migrated, scaled, componentized.
- Collaboration: facilitated, aligned, partnered, presented, negotiated, coached, mentored.
- Leadership: defined, prioritized, established, influenced, hired, led, operationalized.

Avoid vague or inflated verbs when the evidence is thin: revolutionized, transformed, owned everything, single-handedly, world-class.

## Summary Templates

Product/UX designer:

`[Level] product designer with [X years or equivalent experience] designing [product/domain types] for [audience]. Strengths include [2-3 relevant capabilities], with recent work in [target-aligned projects/outcomes].`

UX researcher:

`UX researcher focused on [methods/domain/audience], turning qualitative and quantitative evidence into product decisions. Experienced in [methods], stakeholder alignment, and research communication for [teams/products].`

Visual or brand designer:

`Visual designer specializing in [brand/UI/campaign/system focus], building cohesive visual systems across [channels/products]. Combines craft in [specific skills] with collaboration across [teams/clients].`

Design leader:

`Design leader with experience shaping [product/org/domain] strategy, developing teams, and improving design quality at scale. Known for [leadership strengths] across [cross-functional partners or business contexts].`

## Skills Section Pattern

Group skills by capability, not by a flat tool dump:

- Product design: user flows, IA, wireframing, interaction design, prototyping, usability testing.
- Research: interviews, surveys, journey mapping, synthesis, concept testing, analytics review.
- Systems and craft: design systems, components, accessibility, responsive design, visual design, content design.
- Collaboration: workshops, stakeholder storytelling, PM/engineering handoff, design critique.
- Tools: Figma, FigJam, Miro, Adobe CC, Principle, ProtoPie, Framer, Webflow, Jira, Linear, Notion.

Only include tools and methods the user actually knows.

## Role Keyword Groups

Use these as reminders when tailoring to a job description. Insert only the terms that match the user's real experience.

- Product designer: product strategy, end-to-end design, user flows, interaction design, prototyping, research synthesis, experimentation, metrics, design systems, PM/engineering collaboration.
- UX/UI designer: wireframes, UI design, responsive design, usability testing, high-fidelity prototypes, information architecture, accessibility, component libraries.
- UX researcher: research planning, moderated interviews, usability studies, survey design, thematic analysis, mixed methods, insight storytelling, research repository.
- Design systems designer: tokens, components, patterns, governance, accessibility, documentation, adoption, Figma libraries, front-end partnership.
- Brand or visual designer: identity systems, typography, art direction, campaigns, digital assets, brand guidelines, motion, illustration, production.
- Design manager: coaching, hiring, critique rituals, quality bar, resourcing, roadmap partnership, career growth, cross-functional alignment.

## Before/After Pattern

When showing rewrites, use this compact format:

Original: `Responsible for app redesign and user testing.`

Issue: Activity-based and too vague.

Rewrite: `Redesigned the mobile account setup flow and tested prototypes with new users, giving PM and engineering a clearer release path for onboarding improvements.`

If evidence is missing, include a placeholder:

`Redesigned the mobile account setup flow and tested prototypes with [number/type of users], helping improve [metric or decision] by [result].`

## Visual CV Feedback Pattern

For layout critique, evaluate:

- Information hierarchy: title, portfolio, current role, strongest evidence.
- Readability: type size, line length, spacing, contrast, and mobile/print legibility.
- ATS risk: columns, tables, icons, graphics, hidden links, text boxes, and reading order.
- Designer signal: tasteful typography, restraint, alignment, white space, and consistency.
- Practical recommendation: keep one polished visual version and one ATS-safe version when needed.
