# Designer CV Visual Direction

Use this reference when creating, exporting, or critiquing the visual design of a designer CV.

## Current Rule

Choose one named direction from `designer-cv-template-library.md` and execute it consistently. The library deliberately spans several visual voices; do not flatten them into the same black-and-white two-column CV. Keep every direction legible, evidence-led, and restrained enough for a real application.

The visual design should make the candidate look senior, clear, and credible. It should not look like a template gallery, infographic resume, or poster.

## Shared Aesthetic Standards

- Use a white, ivory, or very pale warm-paper background and black or dark-gray text as the foundation.
- Do not use too many colors. If color is used, allow one accent color, except Soft Studio where the candidate chooses one of two prescribed muted accents.
- Use the accent color sparingly for highlighted text, a small mark, selected headings, or subtle emphasis.
- Use an accent color for text only when it meets WCAG 2.1 AA contrast against its actual background: 4.5:1 for normal text and 3:1 for large text. Keep decorative accents non-textual if their contrast is lower.
- Use no more than two typefaces. Prefer one strong type family with varied weight, size, and style.
- Use italic, bold, and font size changes to support scanning and hierarchy.
- Leave enough white space so the CV feels calm and breathable.
- Use the selected template's block-based 2-column or 3-column layout to create breathing room and clear information grouping.
- Use reasonable line height: open enough for readability, but not so loose that the page feels sparse or disconnected.
- Add personality only in small doses: a small monogram, a quiet rule, a type contrast, or the template's prescribed subtle color field.
- Do not use too many illustrations or icons. They distract from the candidate's evidence and disrupt reading flow.

## Reference Set Observations

The attached examples share these useful patterns:

- Wide margins and a calm white page.
- Header split into 2-3 zones: name/title, portfolio/contact, and sometimes location or phone.
- Strong role/title treatment using size, boldness, or one accent color.
- Main content often arranged as a 2-column layout: primary experience on one side, education/skills/recognition on the other.
- Some examples use a 3-column row rhythm: section label, role metadata, and impact description.
- Section labels are understated; role titles and measurable evidence carry the hierarchy.
- Personal touches are tiny: a signature-like mark, a small monogram, or one restrained accent area.
- The strongest examples rely on typography, grid, and spacing more than decoration.

## Baseline Visual Principles

- Prioritize hierarchy over decoration: name, target role, portfolio, current role, strongest impact.
- Compose the page from four information blocks—contact/identity, experience, education, and supporting information—rather than treating sections as an undifferentiated text flow. Use a named block map from `designer-cv-block-layouts.md`.
- Make the template's visual language unmistakable through its typography, palette, and rhythm—not through decoration.
- Balance breathing room with page utilization. A one-page A4 or Letter CV should feel intentionally full, with the final content reaching near the lower part of the usable page area.
- Keep color restrained. Use mostly black/gray text with one accent color only when it improves hierarchy.
- Avoid progress bars, skill percentage bars, radar charts, large decorative icons, background patterns, and heavy color blocks.
- Make recent experience and measurable impact the visual center of gravity.
- Keep bullets short enough that the page feels crisp, not text-heavy.
- Preserve ATS readability when the output is meant for applications.

## Page-Fill Calibration

After the first layout or PDF render, inspect the full page before delivery.

For one-page visual A4 or Letter outputs:

- Aim for the content to occupy roughly 85-95% of the usable page height.
- A deliberate bottom margin is good; a blank lower quarter or lower third is not.
- If the last content ends too high on the page, adjust the design before exporting.
- Do not solve underfilled pages by adding decorative filler, oversized logos, random icons, excessive line height, or fake content.

Adjustment order for underfilled pages:

1. Increase vertical rhythm in small increments: section gaps, company group spacing, bullet leading, header-to-body gap, and sidebar block spacing.
2. Slightly increase type scale while preserving hierarchy: body text by about 0.5-1 pt, section labels or role titles by about 1-2 pt.
3. Rebalance columns so sidebar and main experience end at more intentional heights; distribute sidebar sections rather than stacking everything too high.
4. Add only meaningful content when the source supports it: selected impact, leadership rituals, portfolio highlights, awards, publications, speaking, mentoring, or case-study links.
5. If content is genuinely too sparse, explain the limitation and provide a cleaner sparse layout rather than padding it.

Adjustment order for overfilled pages:

1. Compress repeated context and weak bullets.
2. Tighten section gaps and line height carefully.
3. Move older or weaker material to a compact sidebar or second page.
4. Reduce type scale only within readable limits.

## Layout Patterns To Prefer

Choose one of these patterns for visual CV outputs:

- **Two-column editorial**: left column for education, skills, awards, and secondary material; right column for experience and leadership impact.
- **Three-column structured rows**: section label, role/company/date metadata, and concise impact bullets or paragraph.
- **Header plus two-column body**: full-width header for name/title/contact, then a 35/65 or 40/60 body split.
- **Sparse one-column**: only when the candidate has little content or ATS safety is the priority.

For senior Product Design Manager or Design Lead CVs:

- Give work experience the largest area.
- Put leadership scope and impact in the highest-visibility column or row.
- Keep skills compact and secondary.
- Avoid letting education, tools, or side activities visually overpower leadership evidence.

## When The User Provides Visual Examples

Analyze the examples before designing:

- Typography: serif/sans, weight contrast, type scale, line height.
- Grid: one-column, two-column, sidebar, modular blocks, margins, spacing rhythm.
- Density: spacious, compact, editorial, portfolio-like, recruiter-first.
- Color: neutral, monochrome, accent color, brand-like treatment.
- Detail level: rules, dividers, labels, tags, icons, link styling.
- What makes the examples feel strong: hierarchy, restraint, craft, memorability, or clarity.

Then map the user's taste to the closest named template, or define a small, named variation with a single palette, type pairing, and layout. Protect readability and evidence.

## Visual Guardrails

- Never use multiple accent colors, except the two Soft Studio alternatives must remain mutually exclusive.
- Never use skill bars or percentage proficiency charts.
- Never use illustrations as section anchors.
- Do not use icon sets unless the user explicitly asks; if used, keep them tiny and functional.
- Do not place text on a busy gradient, image, or pattern.
- Do not make the line height so tall that related content feels disconnected.
- Do not make the layout so sparse that the CV lacks substance.
- Do not make the layout so dense that the candidate's strongest evidence disappears.

## Output Expectations

For PDF:

- Render and inspect the final PDF before delivery whenever tools are available.
- Check that no bullet wraps awkwardly, no text is clipped, and the top third communicates fit immediately.
- Verify that the page uses a white background, black/dark-gray text, no more than one accent color, no more than two typefaces, and enough breathing room.

For Figma:

- Create named text styles for name, title, section heading, role header, bullet, metadata, and link.
- Use frames and layout structure that a designer can continue editing.
- Use a 2-column or 3-column layout unless there is a clear reason not to.
- If no Figma connection exists, provide a Figma-ready spec rather than claiming a file was created.
