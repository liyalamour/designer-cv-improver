# CV Example Index

The bundled `assets/cv-examples/` set is a visual reference library. Use it to inspect proportions, hierarchy, and spacing only. Never reuse names, copy, metrics, portfolio URLs, monograms, or exact visual identity.

| File | Visual cues | Template affinity |
|---|---|---|
| `Elias.png` | Yellow monogram, long-form two-column hierarchy, quiet typewriter-like texture | Professional Experience |
| `Emily.png` | Minimal sans grid, education/skills rail, experience-forward right column | Professional Experience |
| `Josh.png` | Large senior positioning line and restrained editorial serif | Senior Editorial |
| `Joshua.png` | Blue-accent system, functional labels, compact bullets | Product Systems |
| `Louis.png` | Soft gray, broad whitespace, skills rail, dense experience column | Professional Experience |
| `Sanat.png` | Strong blue title, clear two-column hierarchy, methods grouped by capability | Senior Editorial / Product Systems |
| `Sophia.jpeg` | Three-column experience rows, tiny monogram, outcome-focused structure | Evidence-led |
| `graphic-designer.png` | Traditional split with a visible summary and blue section labels | Product Systems |
| `CarolChu.pdf` | Green editorial section labels, three-column evidence rows, generous spacing | Evidence-led / Portfolio Creative |
| `Lee_Eva_Resume.pdf` | Elegant serif name, soft color wash, projects-led content | Portfolio Creative |

When users provide their own visual reference, prioritize it over this library while keeping the library's readability and ATS safeguards.
