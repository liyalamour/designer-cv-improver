# Product Design Manager Screening Standards

Use this reference when screening CVs for Product Design Manager, Senior Product Design Manager, Design Lead, Head of Design, or similar design leadership roles. It encodes Liya's hiring-screening standards and teaching material for designer CVs.

## Core Screening Lens

Look for evidence that the designer can create impact. Strong CVs make impact concrete, preferably quantifiable, and show how design contributed to the outcome.

Prioritize:

- Product and business impact that is specific, credible, and tied to design decisions.
- Career/title growth, especially growth within the same company.
- Leadership scope: team size, cross-functional influence, mentoring, hiring, design-system leadership, operating-model improvements, or strategy ownership.
- Clean, scan-friendly CV structure that lets a hiring manager understand seniority and fit quickly.

Penalize:

- Vague success claims with no scope, metric, or credible attribution to design.
- Frequent company changes without clear growth, progression, or context.
- Internship or part-time roles taking space on senior CVs unless the candidate has limited experience or the role is uniquely relevant.
- Skill progress bars, percentage bars, radar charts, or other visual scoring for skills.

## Must-Have Signals

- Clear target identity in the top third: current/target role, design leadership focus, portfolio link, and strongest positioning.
- Reverse-chronological work history with company, title, dates, location or remote context when useful.
- Evidence of design impact in each major role: what changed, for whom, and why it mattered.
- Leadership evidence for manager/lead roles: team size, scope, rituals, hiring, mentoring, quality bar, roadmap influence, stakeholder management, or cross-functional delivery.
- Experience bullets that start with strong action verbs and describe responsibility, achievement, and impact.
- Concise, data-driven bullets under each experience; senior bullets should not read like long job descriptions.
- Clean layout, readable typography, clear hierarchy, bullet structure, and 1-2 page length.

## Strong Positive Signals

- Career/title progression inside the same company, such as designer to senior designer to lead to manager. Treat this as evidence of growth mindset, trust, and increasing responsibility.
- Quantified impact: conversion, retention, growth, revenue, cost savings, adoption, coverage, quality, speed, research confidence, accessibility, or team efficiency.
- Clear leadership scale: managed a team of designers, led multiple product areas, supported a large design org, or influenced product/design systems across teams.
- Durable design contributions: established design systems from zero to one, improved design-system coverage or adoption, created critique rituals, improved handoff quality, or built team standards.
- Scope that connects product, design, and business: growth, retention, funnel, platform, core experience, vertical ownership, or multi-platform product work.
- Awards, patents, publications, notable shipped projects, or relevant certifications when they support the role story.

## Concern Signals

- Company-hopping: many short tenures without a visible reason, promotion, step-up, relocation, layoff context, or project-based explanation.
- Impact is too vague: "improved user experience", "worked on redesign", "owned product design" without user, product, method, result, or business context.
- Bullets are too long, too many, or too process-heavy, making the candidate's actual impact hard to scan.
- The candidate lists tasks but not outcomes, decisions, tradeoffs, or leadership scope.
- The CV shows tools more prominently than product judgment, design leadership, or results.
- Internship, part-time, or early-school projects consume space on a senior CV while stronger recent experience is underdeveloped.
- The CV claims leadership but gives no team size, mentorship, hiring, operating rhythm, stakeholder influence, or decision-making evidence.

## Reject Signals

- No credible evidence of impact for a senior/leadership role.
- Repeated job changes with no clear growth pattern, role progression, or explanation.
- Claims success that cannot be attributed to design or the candidate's role.
- Skill bars, percentage bars, radar charts, or infographic-heavy layouts that expose perceived weaknesses and do not convey meaningful evidence.
- Background patterns, excessive icons, too many colors, or infographic elements that interfere with scan speed and readability.
- A senior CV that looks visually designed but fails to communicate career progression, scope, impact, or leadership.

## Nice-To-Have Signals

- Portfolio or case-study links that reinforce the CV story.
- Design-system work with adoption or coverage evidence.
- Clear examples of cross-functional partnership with PM, engineering, research, data, business, or executives.
- Awards, publications, patents, talks, teaching, mentoring, community work, or notable projects when relevant and concise.
- A balanced version strategy: ATS-safe PDF for applications and a more polished visual/Figma version for designer-facing contexts.

## CV Structure Standards From Teaching Material

Use a four-block structure unless the candidate's context requires a different order:

1. Contact and identity
   - Include name, email, portfolio or website, LinkedIn, location or work authorization if relevant, and phone when appropriate.
   - Keep social links only when professionally relevant.

2. Work experience
   - Include title, company, dates, and location.
   - Sort from most recent to oldest.
   - For each role, list core responsibilities, achievements, and impact.
   - Start bullets with action verbs.
   - Convert achievements into quantified outcomes whenever truthfully possible.

3. Education
   - Include school, degree, and graduation year.
   - Sort from most recent to oldest.
   - Include awards only when useful.

4. Other or bonus content
   - Include professional skills, certificates/training, awards, publications, patents, and notable projects.
   - Keep this section secondary to recent leadership and impact evidence.

## Layout Standards From Teaching Material

- Make the layout simple, clean, and fast to scan.
- Use professional typography.
- Avoid more than two typefaces or two colors.
- Avoid too many icons.
- Use clear hierarchy for headings and body text.
- Prefer bullet structure for experience.
- Keep content concise and usually within 1-2 pages.
- Size each block according to content importance; for leadership candidates, work experience should dominate.

## Visual Anti-Patterns

Do not use:

- Infographics or charts as the main evidence.
- Skill percentage bars, progress bars, or radar charts.
- More than two colors unless there is a strong brand/layout reason.
- Background images or patterns that reduce readability.
- Decorative layouts that hide contact info, portfolio, titles, dates, or impact.

## Good CV Phrasing Patterns

Use phrasing that combines scope, leadership, and impact:

- Led a team of `[number]` designers across `[product area/platforms]`, improving `[metric/outcome]` through `[design/product work]`.
- Established `[design system/process/team ritual]` from zero to one, expanding adoption from `[baseline]` to `[result]`.
- Managed design for `[product area]`, partnering with PM, engineering, and research to deliver `[launch/outcome]`.
- Redesigned `[flow/product]` to address `[user/business problem]`, contributing to `[provided metric/result]`.

If metrics are missing, ask for them or use scope-based wording:

- Led design for a core funnel across web and mobile, partnering with PM and engineering to define experiments and improve decision quality.

## Weak CV Phrasing Patterns

Flag and rewrite phrases like:

- Responsible for UX/UI.
- Worked on redesign.
- Improved user experience.
- Helped product team.
- Managed designers.
- Designed many screens.

These are weak because they hide scope, leadership behavior, decision quality, and impact.

## Screening Output Format

When the user asks for Product Design Manager screening, use this structure:

1. Screening verdict: strong fit, possible fit, weak fit, or not ready for this level.
2. Must-have gaps: missing evidence that could block interviews.
3. Strong positives: evidence that should stay prominent.
4. Concerns: risks to address or explain.
5. Reject signals: only list if present; be direct and specific.
6. Rewrite priorities: what to change first.
7. Example rewrites: provide truthful before/after bullets or placeholders for missing metrics.

Do not make the critique soft if the CV lacks leadership evidence. Be candid but constructive.
