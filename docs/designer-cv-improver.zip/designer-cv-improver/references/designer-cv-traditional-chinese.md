# Traditional Chinese CV Guidance

Use this reference for Mandarin CVs written in Traditional Chinese (`zh-Hant`), including Taiwan-oriented CVs. Preserve the user's factual claims and official names; localize the writing and layout without translating proper nouns inaccurately.

## Language Workflow

- Detect Traditional Chinese source text and respond in Traditional Chinese unless the user requests English or bilingual output.
- Use one primary language per CV. For bilingual output, give the primary language visual priority and keep the secondary language to the name, role, selected heading, or a separately requested version.
- Retain official company names, degree names, product names, tool names, and certification titles in the official language when a translation could be misleading.
- Do not convert Traditional Chinese to Simplified Chinese. Do not use Cantonese-specific wording unless the user requests Hong Kong localization.

## Recommended Sections

| English | Traditional Chinese default |
|---|---|
| Profile / Summary | 個人簡介 |
| Experience | 工作經歷 |
| Education | 學歷 |
| Skills | 專業技能 |
| Portfolio | 作品集 |
| Awards / Certifications | 獎項與證照 |
| Languages | 語言能力 |
| Selected Projects | 精選專案 |

Use `至今` for a current role and formats such as `2023.06－至今` or `2023 年 6 月－至今`. Keep date formatting consistent throughout.

## Writing Rules

- Lead with an action and outcome, not a literal translation of English grammar.
- Prefer concise, professional Mandarin: `主導`, `規劃`, `設計`, `整合`, `建立`, `優化`, `驗證`, `推動`, `協作`.
- State scope and evidence naturally: `主導結帳流程改版，透過使用者測試與跨職能協作，將……`.
- Use a visible placeholder such as `［成效指標］` or `［使用者數］` when evidence is missing; never invent a metric.
- Avoid inflated phrases such as `顛覆性`, `世界級`, `全方位負責`, or `大幅提升` without evidence.
- Keep bullets short. Prefer one clear sentence per bullet; use full-width punctuation consistently.

## Example Rewrites

Weak:

`負責 App 改版與使用者測試。`

Stronger:

`主導行動 App 帳戶設定流程改版，完成原型測試並彙整使用者回饋，協助產品與工程團隊釐清下一階段優化方向。`

Metric-ready:

`主導行動 App 帳戶設定流程改版，完成［使用者數］位目標使用者測試，將［任務成功率／轉換率］提升至［結果］。`

## CJK Visual Typesetting

- Use a CJK-capable family installed in the environment, such as PingFang TC, Noto Sans TC, or Source Han Sans TC. Never rely on a Latin-only font fallback.
- Use a companion Latin family only when mixed English labels need it; match x-height and weight closely.
- Increase Chinese body leading slightly compared with Latin body copy; start around 1.55–1.7× and adjust after rendering.
- Avoid fully justified Chinese body copy, arbitrary spaces between Chinese characters, narrow all-caps labels, and excessive letter spacing.
- Keep Latin acronyms, email addresses, URLs, and product names unbroken where possible. Check mixed CJK/Latin wrapping manually in the rendered PDF.
- Permit a slightly larger name and section-label scale for Chinese without inflating body text. Verify that `、`, `／`, `－`, parentheses, and full-width punctuation render correctly.

## Layout and Version Comparison

- Use the same four blocks: 1 contact/identity, 2 work experience, 3 education, 4 supporting information.
- Keep Chinese section titles short so they preserve the selected block map: `工作經歷`, `學歷`, `專業技能`, `獎項與證照`.
- When a Traditional Chinese CV is attached for visual improvement, proactively show two rendered previews whenever possible. Label the comparison `版本 A` and `版本 B`; write both descriptions in Traditional Chinese. If rendering is unavailable, show two complete Chinese Figma-ready layout specs instead.
- Prepare Version A and Version B for visual improvement requests just as for English CVs. The versions must differ in visual direction and block composition, not merely language styling.
- After the previews, ask: `我已完成兩個視覺方向。你希望我將哪一個版本延伸為最終履歷：版本 A 還是版本 B？`
- For a bilingual CV, prefer parallel versions (one Traditional Chinese, one English) when the user needs two language deliverables; do not make these count as the two required visual design versions unless their layouts also differ materially.
