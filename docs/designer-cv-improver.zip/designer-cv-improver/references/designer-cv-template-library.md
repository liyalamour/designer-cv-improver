# Designer CV Template Library

Use this library to offer tailored visual directions. These are original layout systems distilled from the bundled reference examples; never copy a candidate's content, personal mark, or exact design.

## 1. Swiss Utility

**Visual style:** Swiss-modern. Bright white field, near-black ink, warm-gray metadata, and a single acid-yellow micro-accent (`#D7FF3F`). Use precise hairline rules, tightly aligned labels, and a small square initial mark only when it suits the candidate.

**Personality:** Calm, exacting, craft-led.

**Best for:** Mid-level and senior product, UX, service, or experience designers with a substantial work history.

**Grid:** A full-width header, then a 35/65 two-column body. Use the narrow rail for skills, education, languages, and selected recognition; reserve the wide column for experience.

**Block composition:** 1 spans the header. 2 is the large left body block. 3 sits upper-right; 4 sits lower-right. This is the “experience-first with a compact credentials rail” option.

**Dynamic fit:** Expand 2 for three or more substantial roles. Keep 3 and 4 compact only when they are genuinely short; when credentials are unusually strong, let 3 take the upper two-thirds of the rail.

**Typography:** One neutral grotesk sans family. Set the name in a crisp medium weight, role titles in semibold, and labels in tracked uppercase. Keep the scale disciplined rather than expressive.

**Reference cues:** Elias, Louis, Emily. Distil their grid discipline, not their identities.

**ATS tradeoff:** Moderate. Produce a one-column companion for systems that parse columns poorly.

## 2. Quiet Editorial

**Visual style:** Contemporary editorial. Use ivory-white (`#FCFBF8`), charcoal (`#1B1B1B`), soft stone metadata, and one deep forest accent (`#1F5A45`). Pair a refined display serif for the positioning statement with a clean sans for all functional information.

**Personality:** Direct, thoughtful, senior.

**Best for:** Senior product designers, design-system practitioners, leads, and designers with a clear point of view.

**Grid:** Header uses name and contacts in a single row. Follow with a two-line positioning statement. Body is 30/70: concise education and recognition on the left, experience and outcomes on the right.

**Block composition:** 1 spans the header with the positioning statement. 2 spans the full central body. 3 and 4 form equal supporting blocks along the bottom. This is the “statement then story” option.

**Dynamic fit:** Choose when the candidate has a strong positioning line and 2–3 cohesive roles. If 4 contains major awards, speaking, or certifications, widen it relative to 3 rather than treating both blocks as equal.

**Typography:** Let the positioning line breathe at a noticeably larger scale; use the serif only for name or statement, never body copy. Use delicate rules and generous white space instead of cards or color blocks.

**Reference cues:** Josh Mateo, Sanat Rath.

**ATS tradeoff:** Moderate. Preserve the statement as selectable text and prepare a linear companion when requested.

## 3. Structured Rows

**Visual style:** Gallery-catalogue. White page, deep ink (`#171717`), pale warm gray dividers, and one muted green accent (`#3E7658`). Make the three-column rhythm the visual signature: label, metadata, then evidence.

**Personality:** Precise, evidence-first, portfolio-like.

**Best for:** Early-career product designers, designers with internships or community leadership, and candidates with several compact roles.

**Grid:** Three-column experience rows: section label (15%), company/title/dates (28%), and impact evidence (57%). Keep the header compact. Place skills in tidy groups at the bottom.

**Block composition:** 1 is a compact top-left identity block. 2 occupies the large central field. 3 and 4 sit side-by-side as a lower band. This is the “evidence gallery with a compact footer” option.

**Dynamic fit:** Choose when 2 contains several short roles or projects. Use the lower band for education and proof of roughly equal weight; if either is sparse, collapse it into a smaller footer rather than creating empty boxes.

**Typography:** Use a clean sans with a strong role weight and low-contrast dates. Keep section labels compact, letter-spaced, and anchored consistently. Optional tiny monogram only; no icon set.

**Reference cues:** Sophia Yang, Carol Chu.

**ATS tradeoff:** Moderate to high. Use only in a visual PDF/Figma version; offer ATS-Safe Linear for application systems.

## 4. Soft Studio

**Visual style:** Soft creative studio. Use a warm paper base (`#FFF9F3`), espresso text (`#27231F`), and one dusty lilac accent (`#A48CB8`) or muted coral accent (`#C97965`)—never both. A very soft, low-opacity color bloom may sit in an empty corner behind no text.

**Personality:** Warm, considered, approachable.

**Best for:** Students, early-career designers, visual/brand candidates, and portfolio-first applications.

**Grid:** 36/64 two-column layout. Left side carries education, tools, and skills; right side carries projects before experience when projects are stronger.

**Block composition:** 1 spans the full header. 3 is an upper-left credentials block; 4 is lower-left; 2 is a tall, uninterrupted right-side experience/project block. This is the “portfolio rail” option.

**Dynamic fit:** Choose when selected projects or visual craft deserve as much attention as employment history. If education is thin, give its rail space to 4; if it is a student CV, let 3 and 4 together outweigh a short 2.

**Typography and color:** Pair a characterful serif display name with a calm sans body. Use rounded spacing and a small underline or monogram as the personality gesture. Keep the rest of the page quiet and the text high contrast.

**Reference cues:** Eva Lee, Carol Chu.

**ATS tradeoff:** Moderate. Avoid decorative gradients behind text, and retain visible standard headings.

## 5. Cobalt System

**Visual style:** Product-system utility. Clean white, ink black (`#111827`), cool gray (`#667085`), and one confident cobalt (`#2457FF`). Use functional dividers, blue section labels, and small rectangular highlight fields—never large banners.

**Personality:** Structured, energetic, delivery-oriented.

**Best for:** Interaction designers, UX/UI candidates, and applicants with technical or design-system depth.

**Grid:** 32/68 two-column layout. The left rail groups education, tools, methods, and languages; the right side uses short achievement bullets under each role.

**Block composition:** 1 occupies the top-left identity block and 4 occupies the top-right supporting block. 2 spans the wide middle field. 3 becomes a full-width closing band. This is the “system dashboard” option.

**Dynamic fit:** Choose when 4 contains credible methods, systems, tools, or certifications that help establish role fit early. If 4 is only a generic skill list, move it below 3 and keep the top-right area empty or use the Swiss Utility template instead.

**Typography and color:** Use a modern sans at firmer weights, with compact metadata and a strong blue role/title emphasis. Make the hierarchy feel like a well-maintained product UI. Do not use proficiency bars or large icons.

**Reference cues:** Joshua Lucas, graphic-designer example.

**ATS tradeoff:** Moderate. Replace pictorial section icons with text labels in the ATS companion.

## 6. ATS-Safe Linear

**Visual style:** Plain-text polished. Pure white, black/dark-gray text, and an optional very faint gray rule. Let typographic hierarchy and spacing do all the visual work.

**Personality:** Clear, modern, recruiter-first.

**Best for:** Any candidate submitting through a job portal, or anyone who prioritizes parsing reliability over visual expression.

**Grid:** Single column, text-first. Header includes name, target role, location/work authorization when relevant, portfolio, email, and LinkedIn. Experience dominates; use compact skill groups below it.

**Block composition:** 1, 2, 3, then 4 stack vertically in reading order. This is the “zero ambiguity” option.

**Dynamic fit:** Use whenever parsing reliability wins. Scale sections with content, but never change their order or place a block in a sidebar.

**Typography and color:** One sans family, black/dark-gray text, optional subtle rule. No columns, tables, icons, text boxes, or graphic labels.

**ATS tradeoff:** Low. This is the default companion to every visual template.

## Template Card Format

Use this exact structure when presenting options:

`**[Template name] - Recommended**`  
`Visual style: [style in 3–6 words]. Blocks: [short block composition]. [One-line personality]. Best for [candidate fit]. [ATS tradeoff].`

Do not show all six templates unless the user asks to browse the full library.
